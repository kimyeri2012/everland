<h1>* 관리자 페이지 *</h1>
    <hr>
    <div class="top_menu">
        <span class="pnt_name">관리자님, 안녕하세요. </span>
        <a href="../login/logout.php">로그아웃</a>
        <a href="../members/mem_info.php">내정보</a>
        <a href="../../index.php">홈페이지</a>
    </div>
    <hr>
    <div class="nav">
        <a href="../../">[홈으로]</a>
        <a href="../members/list.php">[회원관리]</a>
        <a href="../notice/list.php">[공지사항]</a>
        <a href="../event/list.php">[이벤트]</a>
        <a href="../product/list.php">[상품관리]</a>
    </div>